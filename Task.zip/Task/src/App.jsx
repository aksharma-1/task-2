import { useEffect, useState } from "react";
import "./App.css";
import CardView from "./Components/CardView";
import { useDispatch } from "react-redux";
import { fetchPosts, setLoading } from "./Store/postSlice";
import FeedbackForm from "./Components/FeedbackForm";
import Pagination from "./Components/Pagination";

function App() {
  return (
    <div className="p-4">
      <CardView />
      <Pagination />
    </div>
  );
}

export default App;
