export const getFilteredPosts = (posts=[], removedIds=[]) => {
  posts.filter(post => !removedIds.includes(post.id));
};

export const getPostsByPage = (posts=[], page=1, removedIds=[]) => {
  const filtered = getFilteredPosts(posts, removedIds);
  const start = (page - 1) * 6;
  return filtered.slice(start, start + 6);
};
