import { createAsyncThunk, createSlice, current } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchPosts = createAsyncThunk("posts/fetchPosts", async () => {
  const res = await axios.get("https://jsonplaceholder.typicode.com/posts");
  const data = await res.json();
  return data.data;
});

const postSlice = createSlice({
  name: "postsData",
  initialState: {
    allPosts: [],
    currentPage: 1,
    removedIds: [],
    loading: true,
  },
  reducers: {
    setPage: (state, action) => {
      state.currentPage = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    removePost: (state, action) => {
      state.removedIds.push(action.payload);
    },
    setDataToStore: (state, action) => {
      state.allPosts = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchPosts.fulfilled, (state, action) => {
      state.allPosts = action.payload;
    });
  },
});

export const { setLoading, setPage, removePost, setDataToStore } =
  postSlice.actions;
export default postSlice.reducer;
