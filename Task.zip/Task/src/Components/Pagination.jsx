import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setPage } from "../Store/postSlice";

function Pagination() {
  const dispatch = useDispatch();
  const { allPosts, removedIds, currentPage } = useSelector((state) => state.postsData);
  const totalPages = Math.ceil((allPosts.length - removedIds.length) / 6);
  return (
    <div className="flex gap-2 mt-4 justify-center">
      {[...Array(totalPages)].map((_, i) => (
        <button
          key={i}
          onClick={() => dispatch(setPage(i + 1))}
          className={`px-2 py-1 border rounded ${
            currentPage === i + 1 ? "bg-amber-500" : ""
          }`}
        >
          {i + 1}
        </button>
      ))}
    </div>
  );
}

export default Pagination;
