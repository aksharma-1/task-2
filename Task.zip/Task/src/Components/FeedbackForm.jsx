import React, { useState } from "react";

function FeedbackForm({ onClose }) {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setError("All field are required");
      return;
    }
    alert("Feedback submitted!");
    setForm({ name: "", email: "", message: "" });
    setError("");
    onClose();
  };
  return (
    <div className="flex flex-col border rounded bg-white shadow">
        <button onClick={()=>onClose()} className="text-2xl cursor-pointer">x</button>
      <form
        className="p-4"
        onSubmit={handleSubmit}
      >
        <input
          type="text"
          placeholder="Name"
          value={form.name}
          onChange={(e) => {
            setForm({ ...form, name: e.target.value });
          }}
          className="mb-2 p-2 w-full border"
        />
        <input
          type="text"
          placeholder="Email"
          value={form.email}
          onChange={(e) => {
            setForm({ ...form, email: e.target.value });
          }}
          className="mb-2 p-2 w-full border"
        />
        <textarea
          placeholder="Message"
          value={form.message}
          onChange={(e) => {
            setForm({ ...form, message: e.target.value });
          }}
          className="mb-2 p-2 w-full border"
        />
        {error && <p className="text-red-500">{error}</p>}
        <button type="submit" className="p-2 bg-blue-500 text-white rounded">
          Submit
        </button>
      </form>
    </div>
  );
}

export default FeedbackForm;
